
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "book.h"

void addBook(Book **books, int *count) {
    *books = realloc(*books, (*count + 1) * sizeof(Book));

    printf("Title: ");
    fgets((*books)[*count].title, 100, stdin);
    (*books)[*count].title[strcspn((*books)[*count].title, "\n")] = 0;

    printf("Author: ");
    fgets((*books)[*count].author, 100, stdin);
    (*books)[*count].author[strcspn((*books)[*count].author, "\n")] = 0;

    printf("Year: ");
    scanf("%d", &(*books)[*count].year);
    getchar();

    printf("Genre: ");
    fgets((*books)[*count].genre, 50, stdin);
    (*books)[*count].genre[strcspn((*books)[*count].genre, "\n")] = 0;

    printf("Pages: ");
    scanf("%d", &(*books)[*count].pages);
    getchar();

    (*books)[*count].status = 0;
    (*books)[*count].rating = 0;
    (*books)[*count].comment[0] = '\0';

    (*count)++;
    printf("Book added!\n");
}

void listBooks(Book *books, int count) {
    if (count == 0) {
        printf("No books.\n");
        return;
    }
    for (int i = 0; i < count; i++) {
        printf("\n[%d] %s by %s (%d)\n", i+1, books[i].title, books[i].author, books[i].year);
        printf("Genre: %s | Pages: %d\n", books[i].genre, books[i].pages);
        printf("Status: %d | Rating: %.1f\n", books[i].status, books[i].rating);
        printf("Comment: %s\n", books[i].comment);
    }
}

void updateStatus(Book *books, int count) {
    int i, s;
    listBooks(books, count);
    printf("Select book #: ");
    scanf("%d", &i);
    getchar();
    i--;

    printf("0 = unread, 1 = reading, 2 = completed: ");
    scanf("%d", &s);
    getchar();

    books[i].status = s;
    printf("Updated!\n");
}

void addRating(Book *books, int count) {
    int i;
    listBooks(books, count);
    printf("Select book #: ");
    scanf("%d", &i);
    getchar();
    i--;

    if (books[i].status != 2) {
        printf("You must finish the book first.\n");
        return;
    }

    printf("Rating (1-5): ");
    scanf("%f", &books[i].rating);
    getchar();

    printf("Comment: ");
    fgets(books[i].comment, 256, stdin);

    printf("Saved!\n");
}

void searchBooks(Book *books, int count) {
    char key[100];
    printf("Search by title: ");
    fgets(key, 100, stdin);
    key[strcspn(key, "\n")] = 0;

    for (int i = 0; i < count; i++) {
        if (strstr(books[i].title, key)) {
            printf("\nFound: %s by %s\n", books[i].title, books[i].author);
        }
    }
}

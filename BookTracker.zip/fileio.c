
#include <stdio.h>
#include <stdlib.h>
#include "book.h"

void saveBooks(Book *books, int count) {
    FILE *f = fopen("books.dat", "wb");
    if (!f) return;
    fwrite(&count, sizeof(int), 1, f);
    fwrite(books, sizeof(Book), count, f);
    fclose(f);
    printf("Saved.\n");
}

Book* loadBooks(int *count) {
    FILE *f = fopen("books.dat", "rb");
    if (!f) {
        *count = 0;
        return NULL;
    }
    fread(count, sizeof(int), 1, f);
    Book *books = malloc(*count * sizeof(Book));
    fread(books, sizeof(Book), *count, f);
    fclose(f);
    return books;
}

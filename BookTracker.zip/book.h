
#ifndef BOOK_H
#define BOOK_H

typedef struct {
    char title[100];
    char author[100];
    int year;
    char genre[50];
    int pages;
    int status;     // 0 = unread, 1 = reading, 2 = completed
    float rating;
    char comment[256];
} Book;

void addBook(Book **books, int *count);
void listBooks(Book *books, int count);
void updateStatus(Book *books, int count);
void addRating(Book *books, int count);
void searchBooks(Book *books, int count);

void saveBooks(Book *books, int count);
Book* loadBooks(int *count);

#endif


#include <stdio.h>
#include <stdlib.h>
#include "book.h"

int main() {
    Book *books = NULL;
    int count = 0;
    int choice;

    books = loadBooks(&count);

    do {
        printf("\n===== BOOK TRACKER =====\n");
        printf("1. Add New Book\n");
        printf("2. List All Books\n");
        printf("3. Update Status (Unread/Reading/Completed)\n");
        printf("4. Add Rating & Comment\n");
        printf("5. Search Book\n");
        printf("6. Save\n");
        printf("0. Exit\n");
        printf("Choose: ");
        scanf("%d", &choice);
        getchar();

        switch(choice) {
            case 1: addBook(&books, &count); break;
            case 2: listBooks(books, count); break;
            case 3: updateStatus(books, count); break;
            case 4: addRating(books, count); break;
            case 5: searchBooks(books, count); break;
            case 6: saveBooks(books, count); break;
        }
    } while(choice != 0);

    saveBooks(books, count);
    free(books);

    return 0;
}
